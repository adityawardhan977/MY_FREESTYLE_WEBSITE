from flask import Flask, render_template, request, redirect
import mysql.connector

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/signup",methods=['GET','POST'])

def post():
    connection=mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="Free_style_website"
    )

    if request.method=="POST":
             
        username=request.form["username"]
        password=request.form["password"]

        cursor=connection.cursor()
        cursor.execute(
        "INSERT INTO signup_table (username,password) VALUES (%s,%s);",
        (username,password)
        )

        connection.commit()

        cursor.close()
        connection.close()
        
        return render_template("home.html")
    
    return render_template("signup.html")

@app.route("/login",methods=['GET','POST'])

def login_post():
    connection=mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="Free_style_website"
    )

    if request.method=='POST':
        username=request.form["username"]
        password=request.form["password"]

        cursor=connection.cursor(buffered=True)
        cursor.execute(
            "SELECT * FROM signup_table WHERE username = %s AND password = %s",
            (username,password)
        )

        user = cursor.fetchone()

        cursor.close()
        connection.close()

        if user:
            return render_template("home.html")
        else:
            return "invalid password"

    return render_template("login.html")

tasks=[]
@app.route("/to_do_list",methods=['GET','POST'])
def list():
    if request.method=='POST':
        task=request.form["to_do_list"]
        tasks.append(task)
        return redirect("/to_do_list")
    
    return render_template("to_do_list.html", tasks=tasks)

@app.route("/delete/<int:index>")
def pop(index):
    tasks.pop(index)
    return redirect("/to_do_list")

app.run(debug=True)